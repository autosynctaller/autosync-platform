'use client'
import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Loader2 } from 'lucide-react'
export default function AdminRedirect() {
  const router = useRouter()
  useEffect(() => { router.push('/app/admin/dashboard') }, [router])
  return <div className="flex min-h-screen items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
}
